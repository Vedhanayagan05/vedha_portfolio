Put profile.jpg and logo.ico in this folder
